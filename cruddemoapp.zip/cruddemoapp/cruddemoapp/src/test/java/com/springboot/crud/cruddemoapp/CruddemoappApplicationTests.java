package com.springboot.crud.cruddemoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruddemoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
