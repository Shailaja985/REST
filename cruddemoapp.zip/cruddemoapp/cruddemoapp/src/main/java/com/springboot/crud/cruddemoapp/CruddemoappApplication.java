package com.springboot.crud.cruddemoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CruddemoappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CruddemoappApplication.class, args);
	}

}
