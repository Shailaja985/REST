package com.springboot.crud.cruddemoapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.crud.cruddemoapp.entity.Customer;
import com.springboot.crud.cruddemoapp.service.CustomerService;

@RestController
@RequestMapping("/api")
public class CustomerController {
	
	private CustomerService customerService;
	
	@Autowired
	public CustomerController(CustomerService customerService) {
		
		this.customerService = customerService;
	}
	
	//listing all the customers
	
	@GetMapping("/customers")
	public List<Customer> findALL(){
		return customerService.findAll();
	}
	
	
	//finding the customer by id
	
	@GetMapping("/customers/{customerId}")
	public Customer findById(@PathVariable int customerId){
		 Customer customer=customerService.findById(customerId);
		 if(customer == null){
			 throw new RuntimeException("Invalid customer id "+customerId);
		 }
		 return customer;
	}
	
	//adding the customer to the Db
	
	@PostMapping("/customers")
	public Customer addCustomer(@RequestBody Customer customer){
		
		//if in case they set id in JSON .set the id=0
		//forcly adding customer..not updating the customer
		
		customer.setId(0);
		
		customerService.save(customer);
		
		return customer;
	}
	
	//updating the existing customer
	
	@PutMapping("/customers")
	public Customer updateCustomer(@RequestBody Customer customer){
		
		customerService.save(customer);
		
		return customer;
	}
	
	//deleting the a customer from the DB
	
	@DeleteMapping("customers/{customerId}")
	public String deleteCustomers(@PathVariable int customerId){
		
		//find the customer by given id
		Customer customer=customerService.findById(customerId);
		
		//make sure customer is not null
		if(customer == null){
			//System.out.println("customer "+customer);
			throw new RuntimeException("Invalid customer id");
			
		}
		
		//if customer exist -delete that customer from DB
		customerService.deleteById(customerId);
		
		return "deleted customer id "+customerId;
		
		
	}
	
	
	
}
