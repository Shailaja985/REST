package com.springboot.crud.cruddemoapp.dao;

import java.util.List;

import com.springboot.crud.cruddemoapp.entity.Customer;

public interface CustomerDAO {
	
	public List<Customer> findAll();
	
	public Customer findById(int theId);
	
	public void save(Customer customer);
	
	public void deleteById(int theId);
}
